const API = '/api';

function ptoken() {
    return sessionStorage.getItem('participantToken') || '';
}

function atoken() {
    return sessionStorage.getItem('adminToken') || '';
}

function participant() {
    try {
        return JSON.parse(
            sessionStorage.getItem('participant') || 'null'
        );
    } catch (e) {
        return null;
    }
}

function setParticipant(data) {
    sessionStorage.setItem(
        'participantToken',
        data.token || ''
    );

    sessionStorage.setItem(
        'participant',
        JSON.stringify(data)
    );
}

function updateParticipantRound(round) {
    const p = participant();

    if (p) {
        p.currentRound = round;

        sessionStorage.setItem(
            'participant',
            JSON.stringify(p)
        );
    }
}

async function api(path, options = {}) {

    options.headers = options.headers || {};

    if (ptoken()) {
        options.headers['X-Participant-Token'] = ptoken();
    }

    return fetch(API + path, options);
}

async function adminApi(path, options = {}) {

    options.headers = options.headers || {};

    if (atoken()) {
        options.headers['X-Admin-Token'] = atoken();
    }

    return fetch(API + path, options);
}

function jsonOpts(body) {
    return {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
    };
}

function msg(text, type = 'notice') {

    const el = document.getElementById('message');

    if (!el) {
        return;
    }

    el.textContent = text;
    el.className = 'notice ' + type;
    el.classList.remove('hidden');
}

function escapeHtml(value) {

    return String(value ?? '').replace(
        /[&<>'"]/g,
        c => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            "'": '&#39;',
            '"': '&quot;'
        }[c])
    );
}

function requireParticipant() {

    if (!ptoken()) {
        location.replace('/index.html');
        return false;
    }

    return true;
}

function requireAdmin() {

    if (!atoken()) {
        location.replace('/admin.html');
        return false;
    }

    return true;
}

function roundUrl(round) {

    if (Number(round) === 1) return '/round1.html';
    if (Number(round) === 2) return '/round2.html';
    if (Number(round) === 3) return '/round3.html';

    return '/result.html';
}

function goToRound(round) {
    location.replace(roundUrl(round));
}

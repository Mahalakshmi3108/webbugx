package com.webbugx.model;

import jakarta.persistence.*;

@Entity
@Table(name="questions")
public class Question {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false) private int roundNumber;
    @Column(nullable=false) private int questionNumber;
    @Column(nullable=false, columnDefinition="TEXT") private String title;
    @Column(columnDefinition="LONGTEXT") private String content;
    @Column(columnDefinition="LONGTEXT") private String correctAnswer;
    private Integer marks;
    private String targetImage;

    public Question() {}
    public Long getId(){return id;}
    public int getRoundNumber(){return roundNumber;}
    public void setRoundNumber(int v){roundNumber=v;}
    public int getQuestionNumber(){return questionNumber;}
    public void setQuestionNumber(int v){questionNumber=v;}
    public String getTitle(){return title;}
    public void setTitle(String v){title=v;}
    public String getContent(){return content;}
    public void setContent(String v){content=v;}
    public String getCorrectAnswer(){return correctAnswer;}
    public void setCorrectAnswer(String v){correctAnswer=v;}
    public Integer getMarks(){return marks;}
    public void setMarks(Integer v){marks=v;}
    public String getTargetImage(){return targetImage;}
    public void setTargetImage(String v){targetImage=v;}
}

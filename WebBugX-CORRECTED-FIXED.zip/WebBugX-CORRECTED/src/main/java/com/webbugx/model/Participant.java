package com.webbugx.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="participants", uniqueConstraints = @UniqueConstraint(columnNames={"email","phone_number"}))
public class Participant {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false) private String fullName;
    @Column(nullable=false) private String collegeName;
    @Column(nullable=false) private String email;
    @Column(nullable=false) private String phoneNumber;
    @Column(nullable=false) private LocalDateTime registeredAt;
    @Column(nullable=false) private int currentRound = 1;

    public Participant() {}
    public Long getId(){return id;}
    public String getFullName(){return fullName;}
    public void setFullName(String v){fullName=v;}
    public String getCollegeName(){return collegeName;}
    public void setCollegeName(String v){collegeName=v;}
    public String getEmail(){return email;}
    public void setEmail(String v){email=v;}
    public String getPhoneNumber(){return phoneNumber;}
    public void setPhoneNumber(String v){phoneNumber=v;}
    public LocalDateTime getRegisteredAt(){return registeredAt;}
    public void setRegisteredAt(LocalDateTime v){registeredAt=v;}
    public int getCurrentRound(){return currentRound;}
    public void setCurrentRound(int v){currentRound=v;}
}

package com.webbugx.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="round_attempts", uniqueConstraints=@UniqueConstraint(columnNames={"participant_id","round_number"}))
public class RoundAttempt {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional=false) private Participant participant;
    @Column(nullable=false) private int roundNumber;
    @Column(nullable=false) private LocalDateTime startedAt;
    private LocalDateTime submittedAt;
    private Integer score = 0;
    @Column(columnDefinition="LONGTEXT") private String answersJson;
    @Column(columnDefinition="LONGTEXT") private String submittedCode;
    private Boolean autoPassed = false;
    private Boolean adminVerified = false;
    private Integer adminScore = 0;

    public RoundAttempt() {}
    public Long getId(){return id;}
    public Participant getParticipant(){return participant;}
    public void setParticipant(Participant p){participant=p;}
    public int getRoundNumber(){return roundNumber;}
    public void setRoundNumber(int v){roundNumber=v;}
    public LocalDateTime getStartedAt(){return startedAt;}
    public void setStartedAt(LocalDateTime v){startedAt=v;}
    public LocalDateTime getSubmittedAt(){return submittedAt;}
    public void setSubmittedAt(LocalDateTime v){submittedAt=v;}
    public Integer getScore(){return score;}
    public void setScore(Integer v){score=v;}
    public String getAnswersJson(){return answersJson;}
    public void setAnswersJson(String v){answersJson=v;}
    public String getSubmittedCode(){return submittedCode;}
    public void setSubmittedCode(String v){submittedCode=v;}
    public Boolean getAutoPassed(){return autoPassed;}
    public void setAutoPassed(Boolean v){autoPassed=v;}
    public Boolean getAdminVerified(){return adminVerified;}
    public void setAdminVerified(Boolean v){adminVerified=v;}
    public Integer getAdminScore(){return adminScore;}
    public void setAdminScore(Integer v){adminScore=v;}
}

package com.webbugx.repository;

import com.webbugx.model.Question;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface QuestionRepository
        extends JpaRepository<Question, Long> {

    List<Question> findByRoundNumberOrderByQuestionNumber(
            int roundNumber);

    Optional<Question> findFirstByRoundNumberAndQuestionNumber(
            int roundNumber,
            int questionNumber);
}

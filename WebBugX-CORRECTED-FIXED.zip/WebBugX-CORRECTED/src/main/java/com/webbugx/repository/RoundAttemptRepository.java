package com.webbugx.repository;

import com.webbugx.model.RoundAttempt;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RoundAttemptRepository
        extends JpaRepository<RoundAttempt, Long> {

    Optional<RoundAttempt> findByParticipantIdAndRoundNumber(
            Long participantId,
            int roundNumber);

    List<RoundAttempt> findAllByOrderByRoundNumberAsc();

    List<RoundAttempt> findByParticipantId(Long participantId);
}

package com.webbugx.repository;
import com.webbugx.model.Participant;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface ParticipantRepository extends JpaRepository<Participant,Long>{
    Optional<Participant> findByEmailAndPhoneNumber(String email,String phoneNumber);
    boolean existsByEmailAndPhoneNumber(String email,String phoneNumber);
}

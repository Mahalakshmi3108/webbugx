package com.webbugx.controller;
import com.webbugx.model.Question;
import com.webbugx.repository.QuestionRepository;
import org.springframework.web.bind.annotation.*;
import java.util.*;
import java.util.stream.Collectors;
@RestController @RequestMapping("/api/questions")
public class QuestionController {
    private final QuestionRepository repo;
    public QuestionController(QuestionRepository repo){this.repo=repo;}
    @GetMapping("/round/{round}")
    public List<Map<String,Object>> round(@PathVariable int round){
        return repo.findByRoundNumberOrderByQuestionNumber(round).stream().map(this::safe).collect(Collectors.toList());
    }
    private Map<String,Object> safe(Question q){
        Map<String,Object> m=new LinkedHashMap<>(); m.put("id",q.getId());m.put("roundNumber",q.getRoundNumber());m.put("questionNumber",q.getQuestionNumber());m.put("title",q.getTitle());m.put("content",q.getContent());m.put("marks",q.getMarks());m.put("targetImage",q.getTargetImage());
        if(q.getRoundNumber()==1) m.put("options",q.getContent());
        return m;
    }
}

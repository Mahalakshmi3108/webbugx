package com.webbugx.controller;

import com.webbugx.model.Participant;
import com.webbugx.model.RoundAttempt;
import com.webbugx.repository.ParticipantRepository;
import com.webbugx.repository.RoundAttemptRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/participants")
public class ParticipantController {

    private final ParticipantRepository repo;
    private final RoundAttemptRepository attempts;

    public static final Map<String, Long> sessions =
            new ConcurrentHashMap<>();

    public ParticipantController(
            ParticipantRepository repo,
            RoundAttemptRepository attempts) {
        this.repo = repo;
        this.attempts = attempts;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(
            @RequestBody Map<String, String> b) {

        String name = clean(b.get("fullName"));
        String college = clean(b.get("collegeName"));
        String email = clean(b.get("email"));
        String phone = clean(b.get("phoneNumber"));

        if (name.isBlank() || college.isBlank()
                || email.isBlank() || phone.isBlank()) {
            return ResponseEntity.badRequest().body(
                    Map.of("message",
                            "All four registration fields are required."));
        }

        if (repo.existsByEmailAndPhoneNumber(email, phone)) {
            return ResponseEntity.badRequest().body(
                    Map.of("message",
                            "Participant already registered. Please login."));
        }

        Participant p = new Participant();
        p.setFullName(name);
        p.setCollegeName(college);
        p.setEmail(email);
        p.setPhoneNumber(phone);
        p.setRegisteredAt(LocalDateTime.now());
        p.setCurrentRound(1);

        repo.save(p);

        return ResponseEntity.ok(
                Map.of("message",
                        "Registration successful. You can now login."));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(
            @RequestBody Map<String, String> b) {

        String name = clean(b.get("fullName"));
        String college = clean(b.get("collegeName"));
        String email = clean(b.get("email"));
        String phone = clean(b.get("phoneNumber"));

        Optional<Participant> op =
                repo.findByEmailAndPhoneNumber(email, phone);

        if (op.isEmpty()) {
            return ResponseEntity.status(401).body(
                    Map.of("message",
                            "Participant not found. Check email and phone number."));
        }

        Participant p = op.get();

        if (!p.getFullName().equalsIgnoreCase(name)
                || !p.getCollegeName().equalsIgnoreCase(college)) {
            return ResponseEntity.status(401).body(
                    Map.of("message",
                            "Name or college does not match the registration."));
        }

        String token = UUID.randomUUID().toString();
        sessions.put(token, p.getId());

        return ResponseEntity.ok(
                Map.of(
                        "token", token,
                        "participantId", p.getId(),
                        "fullName", p.getFullName(),
                        "collegeName", p.getCollegeName(),
                        "currentRound", p.getCurrentRound()
                )
        );
    }

    /*
     * Public final leaderboard.
     * Only participants who have submitted all three rounds are ranked.
     */
    @GetMapping("/leaderboard")
    public ResponseEntity<?> leaderboard() {

        List<Participant> completed =
                repo.findAll().stream()
                        .filter(p -> p.getCurrentRound() >= 4)
                        .toList();

        List<Map<String, Object>> rows =
                buildLeaderboard(completed);

        return ResponseEntity.ok(rows);
    }

    private List<Map<String, Object>> buildLeaderboard(
            List<Participant> participants) {

        List<Map<String, Object>> rows = new ArrayList<>();

        for (Participant p : participants) {

            List<RoundAttempt> roundAttempts =
                    attempts.findByParticipantId(p.getId());

            int totalScore = roundAttempts.stream()
                    .filter(a -> a.getSubmittedAt() != null)
                    .mapToInt(a -> a.getScore() == null ? 0 : a.getScore())
                    .sum();

            long totalSeconds = roundAttempts.stream()
                    .filter(a -> a.getStartedAt() != null
                            && a.getSubmittedAt() != null)
                    .mapToLong(a -> Math.max(
                            0,
                            Duration.between(
                                    a.getStartedAt(),
                                    a.getSubmittedAt()
                            ).getSeconds()))
                    .sum();

            Map<String, Object> row = new LinkedHashMap<>();
            row.put("participantId", p.getId());
            row.put("fullName", p.getFullName());
            row.put("collegeName", p.getCollegeName());
            row.put("score", totalScore);
            row.put("timeSeconds", totalSeconds);
            row.put("time", formatTime(totalSeconds));

            rows.add(row);
        }

        rows.sort(
                Comparator
                        .comparing(
                                (Map<String, Object> x)
                                        -> (Integer) x.get("score"))
                        .reversed()
                        .thenComparingLong(
                                x -> (Long) x.get("timeSeconds"))
        );

        for (int i = 0; i < rows.size(); i++) {
            rows.get(i).put("rank", i + 1);
            rows.get(i).put(
                    "position",
                    i == 0 ? "WINNER"
                            : i == 1 ? "RUNNER-UP"
                            : ""
            );
        }

        return rows;
    }

    private static String formatTime(long seconds) {
        return String.format(
                "%02d:%02d:%02d",
                seconds / 3600,
                (seconds % 3600) / 60,
                seconds % 60
        );
    }

    static String clean(String s) {
        return s == null ? "" : s.trim();
    }
}

package com.webbugx.controller;

import com.webbugx.model.Participant;
import com.webbugx.model.Question;
import com.webbugx.model.RoundAttempt;
import com.webbugx.repository.ParticipantRepository;
import com.webbugx.repository.QuestionRepository;
import com.webbugx.repository.RoundAttemptRepository;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final ParticipantRepository participants;
    private final QuestionRepository questions;
    private final RoundAttemptRepository attempts;

    private final String adminEmail;
    private final String adminPassword;

    private final Map<String, Boolean> sessions =
            new ConcurrentHashMap<>();

    public AdminController(
            ParticipantRepository participants,
            QuestionRepository questions,
            RoundAttemptRepository attempts,
            @Value("${webbugx.admin.email}") String adminEmail,
            @Value("${webbugx.admin.password}") String adminPassword) {

        this.participants = participants;
        this.questions = questions;
        this.attempts = attempts;
        this.adminEmail = adminEmail;
        this.adminPassword = adminPassword;
    }

    private boolean ok(String token) {
        return token != null
                && Boolean.TRUE.equals(sessions.get(token));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(
            @RequestBody Map<String, String> body) {

        String email = body.getOrDefault("email", "").trim();
        String password = body.getOrDefault("password", "");

        if (adminEmail.equals(email)
                && adminPassword.equals(password)) {

            String token = UUID.randomUUID().toString();
            sessions.put(token, true);

            return ResponseEntity.ok(
                    Map.of(
                            "token", token,
                            "message", "Admin login successful."
                    )
            );
        }

        return ResponseEntity.status(401).body(
                Map.of("message", "Invalid admin login."));
    }

    @GetMapping("/participants")
    public ResponseEntity<?> people(
            @RequestHeader(
                    value = "X-Admin-Token",
                    required = false
            ) String token) {

        if (!ok(token)) {
            return ResponseEntity.status(401).build();
        }

        return ResponseEntity.ok(participants.findAll());
    }

    @GetMapping("/questions/round/{round}")
    public ResponseEntity<?> adminQuestions(
            @RequestHeader(
                    value = "X-Admin-Token",
                    required = false
            ) String token,
            @PathVariable int round) {

        if (!ok(token)) {
            return ResponseEntity.status(401).build();
        }

        return ResponseEntity.ok(
                questions.findByRoundNumberOrderByQuestionNumber(round)
        );
    }

    @GetMapping("/attempts")
    public ResponseEntity<?> allAttempts(
            @RequestHeader(
                    value = "X-Admin-Token",
                    required = false
            ) String token) {

        if (!ok(token)) {
            return ResponseEntity.status(401).build();
        }

        return ResponseEntity.ok(
                attempts.findAll()
                        .stream()
                        .sorted(
                                Comparator
                                        .comparing(
                                                RoundAttempt::getParticipant,
                                                Comparator.comparing(
                                                        Participant::getFullName,
                                                        String.CASE_INSENSITIVE_ORDER
                                                )
                                        )
                                        .thenComparing(
                                                RoundAttempt::getRoundNumber
                                        )
                        )
                        .map(this::view)
                        .collect(Collectors.toList())
        );
    }

    @PostMapping("/round2/{attemptId}/score")
    public ResponseEntity<?> score2(
            @RequestHeader(
                    value = "X-Admin-Token",
                    required = false
            ) String token,
            @PathVariable Long attemptId,
            @RequestBody Map<String, Object> body) {

        if (!ok(token)) {
            return ResponseEntity.status(401).build();
        }

        RoundAttempt attempt =
                attempts.findById(attemptId).orElse(null);

        if (attempt == null || attempt.getRoundNumber() != 2) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "Invalid Round 2 attempt."));
        }

        if (attempt.getSubmittedAt() == null) {
            return ResponseEntity.badRequest().body(
                    Map.of("message",
                            "Participant has not submitted Round 2."));
        }

        int score = number(body.get("score"), 0);
        score = Math.max(0, Math.min(25, score));

        attempt.setAdminScore(score);
        attempt.setScore(score);
        attempt.setAdminVerified(true);

        attempts.save(attempt);

        return ResponseEntity.ok(
                Map.of(
                        "score", score,
                        "message", "Round 2 score saved."
                )
        );
    }

    @PostMapping("/round3/{attemptId}/verify")
    public ResponseEntity<?> verify3(
            @RequestHeader(
                    value = "X-Admin-Token",
                    required = false
            ) String token,
            @PathVariable Long attemptId,
            @RequestBody Map<String, Object> body) {

        if (!ok(token)) {
            return ResponseEntity.status(401).build();
        }

        RoundAttempt attempt =
                attempts.findById(attemptId).orElse(null);

        if (attempt == null || attempt.getRoundNumber() != 3) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "Invalid Round 3 attempt."));
        }

        if (attempt.getSubmittedAt() == null) {
            return ResponseEntity.badRequest().body(
                    Map.of("message",
                            "Participant has not submitted Round 3."));
        }

        int defaultScore =
                attempt.getScore() == null ? 0 : attempt.getScore();

        int score = number(body.get("score"), defaultScore);
        score = Math.max(0, Math.min(20, score));

        attempt.setAdminScore(score);
        attempt.setScore(score);
        attempt.setAdminVerified(true);

        attempts.save(attempt);

        return ResponseEntity.ok(
                Map.of(
                        "score", score,
                        "message", "Round 3 verification saved."
                )
        );
    }

    @GetMapping("/leaderboard")
    public ResponseEntity<?> leaderboard(
            @RequestHeader(
                    value = "X-Admin-Token",
                    required = false
            ) String token) {

        if (!ok(token)) {
            return ResponseEntity.status(401).build();
        }

        List<Participant> completed =
                participants.findAll()
                        .stream()
                        .filter(p -> p.getCurrentRound() >= 4)
                        .toList();

        List<Map<String, Object>> rows =
                new ArrayList<>();

        for (Participant p : completed) {

            List<RoundAttempt> roundAttempts =
                    attempts.findByParticipantId(p.getId());

            int totalScore =
                    roundAttempts.stream()
                            .filter(a -> a.getSubmittedAt() != null)
                            .mapToInt(a ->
                                    a.getScore() == null
                                            ? 0
                                            : a.getScore())
                            .sum();

            long totalSeconds =
                    roundAttempts.stream()
                            .filter(a ->
                                    a.getStartedAt() != null
                                            && a.getSubmittedAt() != null)
                            .mapToLong(a ->
                                    Math.max(
                                            0,
                                            Duration.between(
                                                    a.getStartedAt(),
                                                    a.getSubmittedAt()
                                            ).getSeconds()
                                    ))
                            .sum();

            Map<String, Object> row =
                    new LinkedHashMap<>();

            row.put("participantId", p.getId());
            row.put("fullName", p.getFullName());
            row.put("collegeName", p.getCollegeName());
            row.put("score", totalScore);
            row.put("timeSeconds", totalSeconds);
            row.put("time", formatTime(totalSeconds));

            rows.add(row);
        }

        rows.sort(
                Comparator
                        .comparing(
                                (Map<String, Object> x)
                                        -> (Integer) x.get("score"))
                        .reversed()
                        .thenComparingLong(
                                x -> (Long) x.get("timeSeconds"))
        );

        for (int i = 0; i < rows.size(); i++) {

            rows.get(i).put("rank", i + 1);

            rows.get(i).put(
                    "position",
                    i == 0
                            ? "WINNER"
                            : i == 1
                            ? "RUNNER-UP"
                            : ""
            );
        }

        return ResponseEntity.ok(rows);
    }

    private Map<String, Object> view(RoundAttempt attempt) {

        Map<String, Object> m =
                new LinkedHashMap<>();

        Participant p = attempt.getParticipant();

        m.put("id", attempt.getId());
        m.put("participantId", p.getId());
        m.put("participant", p.getFullName());
        m.put("collegeName", p.getCollegeName());
        m.put("round", attempt.getRoundNumber());
        m.put("startedAt", attempt.getStartedAt());
        m.put("submittedAt", attempt.getSubmittedAt());
        m.put("score",
                attempt.getScore() == null
                        ? 0
                        : attempt.getScore());
        m.put("adminScore",
                attempt.getAdminScore() == null
                        ? 0
                        : attempt.getAdminScore());
        m.put("adminVerified",
                Boolean.TRUE.equals(attempt.getAdminVerified()));
        m.put("autoPassed",
                Boolean.TRUE.equals(attempt.getAutoPassed()));
        m.put("answersJson", attempt.getAnswersJson());
        m.put("submittedCode", attempt.getSubmittedCode());

        return m;
    }

    private static int number(Object value, int fallback) {

        if (value instanceof Number n) {
            return n.intValue();
        }

        if (value != null) {
            try {
                return Integer.parseInt(value.toString());
            } catch (NumberFormatException ignored) {
                // use fallback
            }
        }

        return fallback;
    }

    private static String formatTime(long seconds) {

        return String.format(
                "%02d:%02d:%02d",
                seconds / 3600,
                (seconds % 3600) / 60,
                seconds % 60
        );
    }
}

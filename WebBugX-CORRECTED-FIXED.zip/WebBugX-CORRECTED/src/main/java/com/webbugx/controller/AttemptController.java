package com.webbugx.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.webbugx.model.Participant;
import com.webbugx.model.Question;
import com.webbugx.model.RoundAttempt;
import com.webbugx.repository.ParticipantRepository;
import com.webbugx.repository.QuestionRepository;
import com.webbugx.repository.RoundAttemptRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/attempts")
public class AttemptController {

    private final ParticipantRepository participants;
    private final QuestionRepository questions;
    private final RoundAttemptRepository attempts;
    private final ObjectMapper mapper;

    private static final Map<Integer, Integer> LIMIT_MINUTES =
            Map.of(
                    1, 10,
                    2, 20,
                    3, 20
            );

    public AttemptController(
            ParticipantRepository participants,
            QuestionRepository questions,
            RoundAttemptRepository attempts,
            ObjectMapper mapper) {

        this.participants = participants;
        this.questions = questions;
        this.attempts = attempts;
        this.mapper = mapper;
    }

    private Participant participant(String token) {

        if (token == null || token.isBlank()) {
            return null;
        }

        Long id = ParticipantController.sessions.get(token);

        if (id == null) {
            return null;
        }

        return participants.findById(id).orElse(null);
    }

    /*
     * Start/resume a round.
     * Participants can only enter the round stored in currentRound.
     */
    @PostMapping("/start/{round}")
    public ResponseEntity<?> start(
            @RequestHeader(
                    value = "X-Participant-Token",
                    required = false
            ) String token,
            @PathVariable int round) {

        Participant p = participant(token);

        if (p == null) {
            return ResponseEntity.status(401).body(
                    Map.of("message", "Login required."));
        }

        if (!LIMIT_MINUTES.containsKey(round)) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "Invalid round."));
        }

        int currentRound = p.getCurrentRound();

        if (currentRound != round) {

            String message;

            if (currentRound <= 3) {
                message = "You must complete Round "
                        + currentRound + " first.";
            } else {
                message = "All three rounds are already completed.";
            }

            return ResponseEntity.status(409).body(
                    Map.of(
                            "message", message,
                            "currentRound", currentRound,
                            "nextRound", currentRound
                    )
            );
        }

        Optional<RoundAttempt> old =
                attempts.findByParticipantIdAndRoundNumber(
                        p.getId(),
                        round
                );

        if (old.isPresent()) {

            RoundAttempt existing = old.get();

            if (existing.getSubmittedAt() != null) {
                return ResponseEntity.status(409).body(
                        Map.of(
                                "message",
                                "This round has already been submitted.",
                                "currentRound",
                                p.getCurrentRound(),
                                "nextRound",
                                p.getCurrentRound()
                        )
                );
            }

            long remaining = remainingSeconds(existing);

            if (remaining <= 0) {
                return ResponseEntity.status(408).body(
                        Map.of(
                                "message",
                                "Time for this round has expired.",
                                "remainingSeconds",
                                0
                        )
                );
            }

            return ResponseEntity.ok(
                    Map.of(
                            "attemptId", existing.getId(),
                            "startedAt", existing.getStartedAt(),
                            "submitted", false,
                            "limitMinutes", LIMIT_MINUTES.get(round),
                            "remainingSeconds", remaining
                    )
            );
        }

        RoundAttempt attempt = new RoundAttempt();
        attempt.setParticipant(p);
        attempt.setRoundNumber(round);
        attempt.setStartedAt(LocalDateTime.now());
        attempt.setScore(0);
        attempt.setAdminScore(0);
        attempt.setAdminVerified(false);
        attempt.setAutoPassed(false);

        attempts.save(attempt);

        return ResponseEntity.ok(
                Map.of(
                        "attemptId", attempt.getId(),
                        "startedAt", attempt.getStartedAt(),
                        "submitted", false,
                        "limitMinutes", LIMIT_MINUTES.get(round),
                        "remainingSeconds",
                        LIMIT_MINUTES.get(round) * 60L
                )
        );
    }

    @PostMapping("/round1/submit")
    public ResponseEntity<?> submit1(
            @RequestHeader("X-Participant-Token") String token,
            @RequestBody Map<String, Object> body) throws Exception {

        Participant p = participant(token);

        if (p == null) {
            return ResponseEntity.status(401).body(
                    Map.of("message", "Login required."));
        }

        if (p.getCurrentRound() != 1) {
            return ResponseEntity.status(409).body(
                    Map.of(
                            "message",
                            "Round 1 is not the current round.",
                            "nextRound",
                            p.getCurrentRound()
                    )
            );
        }

        Optional<RoundAttempt> optional =
                attempts.findByParticipantIdAndRoundNumber(
                        p.getId(), 1);

        if (optional.isEmpty()) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "Round 1 was not started."));
        }

        RoundAttempt attempt = optional.get();

        if (attempt.getSubmittedAt() != null) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "Round 1 already submitted."));
        }

        if (isExpired(attempt, 1)) {
            return ResponseEntity.status(408).body(
                    Map.of("message", "Round 1 time has expired."));
        }

        Map<String, String> answers = readAnswers(body);

        int score = 0;

        for (Question q :
                questions.findByRoundNumberOrderByQuestionNumber(1)) {

            String given =
                    answers.get(
                            String.valueOf(q.getQuestionNumber()));

            String correct =
                    q.getCorrectAnswer() == null
                            ? ""
                            : q.getCorrectAnswer();

            if (correct.equalsIgnoreCase(
                    given == null ? "" : given.trim())) {

                score += q.getMarks() == null ? 0 : q.getMarks();
            }
        }

        attempt.setAnswersJson(mapper.writeValueAsString(answers));
        attempt.setScore(score);
        attempt.setSubmittedAt(LocalDateTime.now());

        attempts.save(attempt);

        p.setCurrentRound(2);
        participants.save(p);

        return ResponseEntity.ok(
                Map.of(
                        "score", score,
                        "maxScore", 15,
                        "nextRound", 2,
                        "message",
                        "Round 1 submitted successfully. Proceed to Round 2."
                )
        );
    }

    @PostMapping("/round2/submit")
    public ResponseEntity<?> submit2(
            @RequestHeader("X-Participant-Token") String token,
            @RequestBody Map<String, Object> body) throws Exception {

        Participant p = participant(token);

        if (p == null) {
            return ResponseEntity.status(401).body(
                    Map.of("message", "Login required."));
        }

        if (p.getCurrentRound() != 2) {
            return ResponseEntity.status(409).body(
                    Map.of(
                            "message",
                            "Round 2 is not the current round.",
                            "nextRound",
                            p.getCurrentRound()
                    )
            );
        }

        Optional<RoundAttempt> optional =
                attempts.findByParticipantIdAndRoundNumber(
                        p.getId(), 2);

        if (optional.isEmpty()) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "Round 2 was not started."));
        }

        RoundAttempt attempt = optional.get();

        if (attempt.getSubmittedAt() != null) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "Round 2 already submitted."));
        }

        if (isExpired(attempt, 2)) {
            return ResponseEntity.status(408).body(
                    Map.of("message", "Round 2 time has expired."));
        }

        Map<String, String> answers = readAnswers(body);

        /*
         * Round 2 is manually evaluated by the administrator.
         * Initial participant score is therefore 0.
         */
        attempt.setAnswersJson(mapper.writeValueAsString(answers));
        attempt.setScore(0);
        attempt.setSubmittedAt(LocalDateTime.now());

        attempts.save(attempt);

        p.setCurrentRound(3);
        participants.save(p);

        return ResponseEntity.ok(
                Map.of(
                        "score", 0,
                        "maxScore", 25,
                        "nextRound", 3,
                        "message",
                        "Round 2 submitted. Admin will verify the debugging answers."
                )
        );
    }

    @PostMapping("/round3/submit")
    public ResponseEntity<?> submit3(
            @RequestHeader("X-Participant-Token") String token,
            @RequestBody Map<String, Object> body) throws Exception {

        Participant p = participant(token);

        if (p == null) {
            return ResponseEntity.status(401).body(
                    Map.of("message", "Login required."));
        }

        if (p.getCurrentRound() != 3) {
            return ResponseEntity.status(409).body(
                    Map.of(
                            "message",
                            "Round 3 is not the current round.",
                            "nextRound",
                            p.getCurrentRound()
                    )
            );
        }

        Optional<RoundAttempt> optional =
                attempts.findByParticipantIdAndRoundNumber(
                        p.getId(), 3);

        if (optional.isEmpty()) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "Round 3 was not started."));
        }

        RoundAttempt attempt = optional.get();

        if (attempt.getSubmittedAt() != null) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "Round 3 already submitted."));
        }

        if (isExpired(attempt, 3)) {
            return ResponseEntity.status(408).body(
                    Map.of("message", "Round 3 time has expired."));
        }

        Map<String, String> answers = readAnswers(body);

        int autoScore = 0;
        List<Question> round3Questions =
                questions.findByRoundNumberOrderByQuestionNumber(3);

        List<String> submittedInQuestionOrder = new ArrayList<>();

        for (Question q : round3Questions) {

            String given =
                    answers.get(
                            String.valueOf(q.getQuestionNumber()));

            submittedInQuestionOrder.add(
                    given == null ? "" : given);

            String correct =
                    q.getCorrectAnswer() == null
                            ? ""
                            : q.getCorrectAnswer();

            if (normalize(given).equals(normalize(correct))) {
                autoScore += q.getMarks() == null ? 0 : q.getMarks();
            }
        }

        attempt.setAnswersJson(mapper.writeValueAsString(answers));
        attempt.setSubmittedCode(
                String.join(
                        "\n---QUESTION---\n",
                        submittedInQuestionOrder
                )
        );
        attempt.setScore(autoScore);
        attempt.setAutoPassed(autoScore == 20);
        attempt.setSubmittedAt(LocalDateTime.now());

        attempts.save(attempt);

        p.setCurrentRound(4);
        participants.save(p);

        return ResponseEntity.ok(
                Map.of(
                        "autoScore", autoScore,
                        "maxScore", 20,
                        "nextRound", 4,
                        "message",
                        "Round 3 submitted. Admin verification is available."
                )
        );
    }

    private Map<String, String> readAnswers(
            Map<String, Object> body) {

        Object raw = body.get("answers");

        if (raw == null) {
            return new LinkedHashMap<>();
        }

        Map<String, String> answers =
                mapper.convertValue(
                        raw,
                        new TypeReference<Map<String, String>>() {
                        }
                );

        return answers == null
                ? new LinkedHashMap<>()
                : answers;
    }

    private boolean isExpired(
            RoundAttempt attempt,
            int round) {

        if (attempt.getStartedAt() == null) {
            return true;
        }

        long allowed =
                LIMIT_MINUTES.get(round) * 60L;

        long elapsed =
                Duration.between(
                        attempt.getStartedAt(),
                        LocalDateTime.now()
                ).getSeconds();

        return elapsed > allowed + 2;
    }

    private long remainingSeconds(
            RoundAttempt attempt) {

        long allowed =
                LIMIT_MINUTES.get(attempt.getRoundNumber()) * 60L;

        long elapsed =
                Math.max(
                        0,
                        Duration.between(
                                attempt.getStartedAt(),
                                LocalDateTime.now()
                        ).getSeconds()
                );

        return Math.max(0, allowed - elapsed);
    }

    private String normalize(String s) {

        if (s == null) {
            return "";
        }

        return s
                .replace("\r\n", "\n")
                .replace("\r", "\n")
                .replaceAll("\\s+", "")
                .toLowerCase(Locale.ROOT);
    }
}

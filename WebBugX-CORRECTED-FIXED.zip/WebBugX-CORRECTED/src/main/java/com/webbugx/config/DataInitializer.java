package com.webbugx.config;

import com.webbugx.model.Question;
import com.webbugx.repository.QuestionRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

@Configuration
public class DataInitializer {

    private String read(String name) throws Exception {

        try (InputStream in =
                     new ClassPathResource(
                             "data/" + name
                     ).getInputStream()) {

            return new String(
                    in.readAllBytes(),
                    StandardCharsets.UTF_8
            );
        }
    }

    private void add(
            QuestionRepository repo,
            int round,
            int number,
            String title,
            String content,
            String answer,
            int marks,
            String image) {

        Question q = new Question();

        q.setRoundNumber(round);
        q.setQuestionNumber(number);
        q.setTitle(title);
        q.setContent(content);
        q.setCorrectAnswer(answer);
        q.setMarks(marks);
        q.setTargetImage(image);

        repo.save(q);
    }

    @Bean
    CommandLineRunner seed(QuestionRepository repo) {

        return args -> {

            /*
             * The question files are the source of truth for this event.
             * We recreate only the question table data on startup so an
             * older database cannot leave stale/extra questions behind.
             *
             * Participant registrations and round attempts are untouched.
             */
            repo.deleteAll();

            String[] titles = {
                    "Which HTML tag is used to create a hyperlink?",
                    "Which semantic HTML element is used to define a section?",
                    "Which HTML tag is used to display an image?",
                    "Which CSS selector targets an element with id=\"menu\"?",
                    "Which CSS property adds space outside an element?",
                    "Which declaration makes an element a flexbox container?",
                    "Which CSS selector has the highest specificity?",
                    "What is the result of typeof 100 in JavaScript?",
                    "What is the result of \"10\" + 5?",
                    "What is the result of 10 == \"10\"?",
                    "Which variable is block-scoped?",
                    "What is typeof null?",
                    "What is NaN === NaN?",
                    "What is [] == false?",
                    "Which property hides an element while retaining its layout space?"
            };

            String[] options = {
                    "A) <link>\nB) <a>\nC) <href>\nD) <url>",
                    "A) <div>\nB) <article>\nC) <section>\nD) <span>",
                    "A) <picture>\nB) <image>\nC) <img>\nD) <src>",
                    "A) .menu\nB) #menu\nC) menu\nD) *menu",
                    "A) padding\nB) border\nC) margin\nD) spacing",
                    "A) flex: true;\nB) position: flex;\nC) display: flex;\nD) flexbox: on;",
                    "A) Element Selector\nB) Class Selector\nC) ID Selector\nD) Universal Selector",
                    "A) string\nB) integer\nC) number\nD) float",
                    "A) 15\nB) 105\nC) \"105\"\nD) Error",
                    "A) true\nB) false\nC) undefined\nD) Error",
                    "A) var\nB) let\nC) constable\nD) static",
                    "A) null\nB) object\nC) undefined\nD) boolean",
                    "A) true\nB) false\nC) NaN\nD) Error",
                    "A) true\nB) false\nC) undefined\nD) TypeError",
                    "A) display:none;\nB) visibility:hidden;\nC) opacity:0;\nD) hidden:true;"
            };

            String[] answers = {
                    "B", "C", "C", "B", "C",
                    "C", "C", "C", "B", "A",
                    "B", "B", "B", "A", "B"
            };

            for (int i = 0; i < 15; i++) {

                add(
                        repo,
                        1,
                        i + 1,
                        titles[i],
                        options[i],
                        answers[i],
                        1,
                        null
                );
            }

            for (int i = 1; i <= 5; i++) {

                add(
                        repo,
                        2,
                        i,
                        "Round 2 — Debugging Question " + i,
                        read("r2_q" + i + "_buggy.html"),
                        read("r2_q" + i + "_correct.html"),
                        5,
                        null
                );
            }

            add(
                    repo,
                    3,
                    1,
                    "Round 3 — Weather Dashboard",
                    read("r3_q1_buggy.html"),
                    read("r3_q1_correct.html"),
                    10,
                    "/targets/round3-q1-weather.jpg"
            );

            add(
                    repo,
                    3,
                    2,
                    "Round 3 — Student Portfolio Dashboard",
                    read("r3_q2_buggy.html"),
                    read("r3_q2_correct.html"),
                    10,
                    "/targets/round3-q2-portfolio.jpg"
            );
        };
    }
}
